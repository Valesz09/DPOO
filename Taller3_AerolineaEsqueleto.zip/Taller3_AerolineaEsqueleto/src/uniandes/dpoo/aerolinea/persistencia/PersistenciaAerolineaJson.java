package uniandes.dpoo.aerolinea.persistencia;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.json.JSONObject;

import uniandes.dpoo.aerolinea.exceptions.InformacionInconsistenteException;
import uniandes.dpoo.aerolinea.modelo.Aerolinea;

public class PersistenciaAerolineaJson implements IPersistenciaAerolinea {

	@Override
	public void cargarAerolinea(String archivo, Aerolinea aerolinea) throws IOException, InformacionInconsistenteException {	
	    try {
	        String jsonCompleto = new String(Files.readAllBytes(new File(archivo).toPath()));
	        JSONObject raiz = new JSONObject(jsonCompleto);

	    } catch (IOException e) {
	        throw new IOException("Error leyendo el archivo: " + archivo, e);
	    } catch (Exception e) {
			throw new InformacionInconsistenteException("Error procesando el archivo JSON ");
		}
	}

	public void salvarAerolinea( String archivo, Aerolinea aerolinea ) {
	    }

}
