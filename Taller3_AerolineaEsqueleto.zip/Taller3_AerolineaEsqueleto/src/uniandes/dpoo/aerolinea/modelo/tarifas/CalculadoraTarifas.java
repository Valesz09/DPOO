package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public abstract class CalculadoraTarifas {

	public static final double IMPUESTO = 0.28;
	
	
	public int calcularTarifa(Vuelo vuelo, Cliente cliente) {
		return 1; 
	}
	
	protected abstract int calcularCostoBase(Vuelo vuelo, Cliente cliente);
	
	protected abstract double calcularPorcentajeDescuento(Cliente cliente);
	
	protected int calcularDistanciaVuelo(Ruta ruta) {
		Aeropuerto aeropuertoOrigen = ruta.getOrigen();
		Aeropuerto aeropuertoDestino = ruta.getDestino();
		
		return Aeropuerto.calcularDistancia(aeropuertoOrigen, aeropuertoDestino);
	}
	
	protected int calcularValorImpuestos(int costoBase) {
		int resultado = (int) (IMPUESTO * costoBase);
		return resultado;
	}
}
